package com.unitbv.operatii;

import com.unitbv.model.Set;

import java.util.ArrayList;
import java.util.List;

public class OperatiiScor {

}
